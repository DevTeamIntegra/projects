sap.ui.define(["./utilities"],function(){"use strict";return{}});
//# sourceMappingURL=utilities.js.map